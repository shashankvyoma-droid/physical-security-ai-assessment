"""Physical security analytics package."""

